from typing import Union
import numpy as np
import torch as th



T_ARRAY = Union[th.Tensor, np.ndarray]